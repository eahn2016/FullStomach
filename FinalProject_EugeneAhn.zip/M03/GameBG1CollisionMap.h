
//{{BLOCK(GameBG1CollisionMap)

//======================================================================
//
//	GameBG1CollisionMap, 512x256@16, 
//	+ bitmap not compressed
//	Total size: 262144 = 262144
//
//	Time-stamp: 2017-12-04, 16:17:37
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_GAMEBG1COLLISIONMAP_H
#define GRIT_GAMEBG1COLLISIONMAP_H

#define GameBG1CollisionMapBitmapLen 262144
extern const unsigned short GameBG1CollisionMapBitmap[131072];

#endif // GRIT_GAMEBG1COLLISIONMAP_H

//}}BLOCK(GameBG1CollisionMap)
