
//{{BLOCK(GameBG0CollisionMap)

//======================================================================
//
//	GameBG0CollisionMap, 512x256@16, 
//	+ bitmap not compressed
//	Total size: 262144 = 262144
//
//	Time-stamp: 2017-12-03, 21:22:39
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_GAMEBG0COLLISIONMAP_H
#define GRIT_GAMEBG0COLLISIONMAP_H

#define GameBG0CollisionMapBitmapLen 262144
extern const unsigned short GameBG0CollisionMapBitmap[131072];

#endif // GRIT_GAMEBG0COLLISIONMAP_H

//}}BLOCK(GameBG0CollisionMap)
