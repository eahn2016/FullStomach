
//{{BLOCK(test)

//======================================================================
//
//	test, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 1013 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 32416 + 2048 = 34976
//
//	Time-stamp: 2017-11-28, 15:30:01
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_TEST_H
#define GRIT_TEST_H

#define testTilesLen 32416
extern const unsigned short testTiles[16208];

#define testMapLen 2048
extern const unsigned short testMap[1024];

#define testPalLen 512
extern const unsigned short testPal[256];

#endif // GRIT_TEST_H

//}}BLOCK(test)
