
//{{BLOCK(GameBG2CollisionMap)

//======================================================================
//
//	GameBG2CollisionMap, 512x256@16, 
//	+ bitmap not compressed
//	Total size: 262144 = 262144
//
//	Time-stamp: 2017-12-03, 23:59:38
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_GAMEBG2COLLISIONMAP_H
#define GRIT_GAMEBG2COLLISIONMAP_H

#define GameBG2CollisionMapBitmapLen 262144
extern const unsigned short GameBG2CollisionMapBitmap[131072];

#endif // GRIT_GAMEBG2COLLISIONMAP_H

//}}BLOCK(GameBG2CollisionMap)
