
//{{BLOCK(GameBG0Behind)

//======================================================================
//
//	GameBG0Behind, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 468 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 14976 + 2048 = 17536
//
//	Time-stamp: 2017-12-02, 21:11:08
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_GAMEBG0BEHIND_H
#define GRIT_GAMEBG0BEHIND_H

#define GameBG0BehindTilesLen 14976
extern const unsigned short GameBG0BehindTiles[7488];

#define GameBG0BehindMapLen 2048
extern const unsigned short GameBG0BehindMap[1024];

#define GameBG0BehindPalLen 512
extern const unsigned short GameBG0BehindPal[256];

#endif // GRIT_GAMEBG0BEHIND_H

//}}BLOCK(GameBG0Behind)
