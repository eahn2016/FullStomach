
//{{BLOCK(ghost)

//======================================================================
//
//	ghost, 240x160@16, 
//	+ bitmap not compressed
//	Total size: 76800 = 76800
//
//	Time-stamp: 2017-12-05, 15:06:20
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_GHOST_H
#define GRIT_GHOST_H

#define ghostBitmapLen 76800
extern const unsigned short ghostBitmap[38400];

#endif // GRIT_GHOST_H

//}}BLOCK(ghost)
