void initCutscene();
void drawCutscene();
void drawCSTextCenter(char *);
void drawEnter();

extern int textSeed;