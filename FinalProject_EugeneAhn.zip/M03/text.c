#include "myLib.h"
#include "text.h"
#include "font.h"

void drawChar(int row, int col, char ch, unsigned short color) {
    for (int r = 0; r < 8; r++) {
        for (int c = 0; c < 6; c++) {
            if (fontdata_6x8[ch * 48 + OFFSET(r, c, 6)]) {
                setPixel3(row + r, col + c, color);
            }
        }
    }
}

void drawString(int row, int col, char *str, unsigned short color) {
    while(*str != '\0') {
        drawChar(row, col, *str, color);
        col += 6;
        str++;
    }
}